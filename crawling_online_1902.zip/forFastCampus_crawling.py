import requests
from bs4 import BeautifulSoup

URL = "https://www.fastcampus.co.kr/category_dev_open/"

response = requests.get(url=URL)
soup = BeautifulSoup(response.text, "html.parser")
get_all_course = soup.find_all("div", {"class": "course"})  # list 형태로 저장된다.


def parsing_course(elements):
    print("-"*100)
    print("강의명: ",elements.find("strong").text)
    print(elements.find("a").text)
    print(elements.find("a")["href"])



for i in get_all_course:
    parsing_course(i)
    #print(i)

